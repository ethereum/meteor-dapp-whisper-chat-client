(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['frozeman:animation-helper'] = {};

})();

//# sourceMappingURL=frozeman_animation-helper.js.map
