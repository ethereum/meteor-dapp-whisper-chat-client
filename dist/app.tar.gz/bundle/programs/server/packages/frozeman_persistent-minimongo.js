(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['frozeman:persistent-minimongo'] = {};

})();

//# sourceMappingURL=frozeman_persistent-minimongo.js.map
