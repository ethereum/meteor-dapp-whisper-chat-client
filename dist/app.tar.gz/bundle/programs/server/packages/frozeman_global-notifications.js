(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

/* Package-scope variables */
var GlobalNotification, GlobalNotifications;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['frozeman:global-notifications'] = {
  GlobalNotification: GlobalNotification,
  GlobalNotifications: GlobalNotifications
};

})();

//# sourceMappingURL=frozeman_global-notifications.js.map
