(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['chuangbo:cookie'] = {};

})();

//# sourceMappingURL=chuangbo_cookie.js.map
