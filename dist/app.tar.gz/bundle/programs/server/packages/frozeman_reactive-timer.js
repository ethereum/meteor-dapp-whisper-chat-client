(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

/* Package-scope variables */
var ReactiveTimer;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['frozeman:reactive-timer'] = {
  ReactiveTimer: ReactiveTimer
};

})();

//# sourceMappingURL=frozeman_reactive-timer.js.map
