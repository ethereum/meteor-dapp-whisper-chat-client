(function(){TAPi18n._enable({"helper_name":"i18n","supported_languages":["en","de"],"i18n_files_route":"/i18n","cdn_path":null});
TAPi18n.languages_names["en"] = ["English","English"];
TAPi18n.languages_names["en"] = ["English","English"];
TAPi18n.languages_names["de"] = ["German","Deutsch"];

})();
